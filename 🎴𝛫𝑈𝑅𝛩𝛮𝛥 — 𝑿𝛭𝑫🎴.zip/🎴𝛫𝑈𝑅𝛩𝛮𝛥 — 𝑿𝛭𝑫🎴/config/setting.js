import fs from "fs";
import path from "path";

// ─────────── Bot Settings ───────────
export const botSettings = {
  name: "𝛫𝑈𝑅𝛩𝛮𝛥 — 𝑿𝛭𝑫",
  version: "v1.0.0",
  mode: "Public",
  prefix: ".",
  owner: {
    name: "🎴 𝑫𝛯𝑽 ᬁ 𝛫𝑈𝑅𝛩𝛮𝛥🎴",
    number: "+237689360833",
  },
  timezone: "Africa/Douala",
  dateFormat: "DD/MM/YYYY",
  timeFormat: "HH:mm:ss",
};

// ─────────── Users ───────────
export let users = {
  creator: ["237683614362@s.whatsapp.net"],
  premium: ["237683614362@s.whatsapp.net"],
  sudo: [],
};

// ─────────── Auto Features ───────────
export const autoFeatures = {
  autoreact: true,
  autotype: true,
  respons: true,
  welcome: true,
  antimention: false,
  antilink: false,
  antibot: false,
};

// ─────────── Group Settings ───────────
export const groupSettings = {
  mute: false,
  settag: true,
};

// ─────────── Media Settings ───────────
export const mediaSettings = {
  saveMedia: true,
  sticker: true,
  toAudio: true,
  photo: true,
};

// ─────────── Downloader Settings ───────────
export const downloaderSettings = {
  ytmp3: true,
  ytmp4: true,
  play: true,
  tiktok: true,
  fb: true,
  ig: true,
};

// ─────────── Bug Commands ───────────
export const bugCommands = ["d-samy","evil-kill", "crash", "invi-darkness", "kuroinvi-ios", "gcbug"];

// ─────────── Helpers ───────────
export const getDate = () => {
  const moment = require("moment-timezone");
  return moment().tz(botSettings.timezone).format(botSettings.dateFormat);
};
export const getTime = () => {
  const moment = require("moment-timezone");
  return moment().tz(botSettings.timezone).format(botSettings.timeFormat);
};

// ─────────── Save Config Dynamically ───────────
export const saveConfig = (filePath = "./config.json") => {
  const data = {
    botSettings,
    users,
    autoFeatures,
    groupSettings,
    mediaSettings,
    downloaderSettings,
    bugCommands,
  };
  fs.writeFileSync(path.resolve(filePath), JSON.stringify(data, null, 2));
};